$(function(){
	$('.badge').tooltip();
});